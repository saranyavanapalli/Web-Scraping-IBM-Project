```python
import pandas as pd
import matplotlib.pyplot as plt
import requests
from bs4 import BeautifulSoup
import yfinance as yf
```


```python
tesla_data = yf.download('TSLA', start='2020-01-01', end='2021-01-01')

# Reset index
tesla_data.reset_index(inplace=True)

# Save the data (optional)
tesla_data.to_csv('tesla_stock_data.csv')

# Display the first five rows
tesla_data.head()
```

    [*********************100%%**********************]  1 of 1 completed
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-02</td>
      <td>28.299999</td>
      <td>28.713333</td>
      <td>28.114000</td>
      <td>28.684000</td>
      <td>28.684000</td>
      <td>142981500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-03</td>
      <td>29.366667</td>
      <td>30.266666</td>
      <td>29.128000</td>
      <td>29.534000</td>
      <td>29.534000</td>
      <td>266677500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-06</td>
      <td>29.364668</td>
      <td>30.104000</td>
      <td>29.333332</td>
      <td>30.102667</td>
      <td>30.102667</td>
      <td>151995000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-07</td>
      <td>30.760000</td>
      <td>31.441999</td>
      <td>30.224001</td>
      <td>31.270666</td>
      <td>31.270666</td>
      <td>268231500</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-08</td>
      <td>31.580000</td>
      <td>33.232666</td>
      <td>31.215334</td>
      <td>32.809334</td>
      <td>32.809334</td>
      <td>467164500</td>
    </tr>
  </tbody>
</table>
</div>




```python
import requests
from bs4 import BeautifulSoup

url = 'https://www.macrotrends.net/stocks/charts/TSLA/tesla/revenue'

# Define headers
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
}

# Send a GET request with headers
response = requests.get(url, headers=headers)

# Check if the request was successful
if response.status_code == 200:
    # Parse HTML content
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find the table containing revenue data
    table = soup.find('table', class_='historical_data_table')

    # Check if the table was found
    if table:
        # Convert the table into a dataframe
        tesla_revenue = pd.read_html(str(table))[0]

        # Display the last five rows
        print(tesla_revenue.tail())
    else:
        print("No table found on the page.")
else:
    print("Failed to retrieve data from the website.")


```

        Tesla Annual Revenue (Millions of US $)  \
    10                                     2013   
    11                                     2012   
    12                                     2011   
    13                                     2010   
    14                                     2009   
    
       Tesla Annual Revenue (Millions of US $).1  
    10                                    $2,013  
    11                                      $413  
    12                                      $204  
    13                                      $117  
    14                                      $112  
    

    C:\Users\saran\AppData\Local\Temp\ipykernel_28648\2080237696.py:25: FutureWarning: Passing literal html to 'read_html' is deprecated and will be removed in a future version. To read from a literal string, wrap it in a 'StringIO' object.
      tesla_revenue = pd.read_html(str(table))[0]
    


```python
# Extract GameStop stock data
gme_data = yf.download('GME', start='2020-01-01', end='2021-01-01')

# Reset index
gme_data.reset_index(inplace=True)

# Save the data (optional)
gme_data.to_csv('gme_stock_data.csv')

# Display the first five rows
gme_data.head()
```

    [*********************100%%**********************]  1 of 1 completed
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-02</td>
      <td>1.5350</td>
      <td>1.6175</td>
      <td>1.5175</td>
      <td>1.5775</td>
      <td>1.5775</td>
      <td>17814400</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-03</td>
      <td>1.5525</td>
      <td>1.5625</td>
      <td>1.4600</td>
      <td>1.4700</td>
      <td>1.4700</td>
      <td>14175600</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-06</td>
      <td>1.4500</td>
      <td>1.4775</td>
      <td>1.4000</td>
      <td>1.4625</td>
      <td>1.4625</td>
      <td>13579200</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-07</td>
      <td>1.4425</td>
      <td>1.4575</td>
      <td>1.3600</td>
      <td>1.3800</td>
      <td>1.3800</td>
      <td>20912000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-08</td>
      <td>1.3725</td>
      <td>1.4625</td>
      <td>1.3525</td>
      <td>1.4300</td>
      <td>1.4300</td>
      <td>22517600</td>
    </tr>
  </tbody>
</table>
</div>




```python
import pandas as pd
import requests
from bs4 import BeautifulSoup

# Define the URL for GameStop revenue data
gme_url = 'https://www.macrotrends.net/stocks/charts/GME/gamestop/revenue'

# Define headers to mimic a browser request
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

# Send a GET request to the URL with headers
gme_response = requests.get(gme_url, headers=headers)

# Check if the request was successful
if gme_response.status_code == 200:
    # Parse the HTML content
    gme_soup = BeautifulSoup(gme_response.content, 'html.parser')
    
    # Find the table containing revenue data
    gme_table = gme_soup.find('table', class_='historical_data_table')
    
    # Check if the table was found
    if gme_table:
        # Convert the table into a dataframe
        gme_revenue = pd.read_html(str(gme_table))[0]
        
        # Display the last five rows
        print(gme_revenue.tail())
    else:
        print("No table found on the page.")
else:
    print("Failed to retrieve data from the website.")

```

        GameStop Annual Revenue (Millions of US $)  \
    11                                        2013   
    12                                        2012   
    13                                        2011   
    14                                        2010   
    15                                        2009   
    
       GameStop Annual Revenue (Millions of US $).1  
    11                                       $8,887  
    12                                       $9,551  
    13                                       $9,474  
    14                                       $9,078  
    15                                       $8,806  
    

    C:\Users\saran\AppData\Local\Temp\ipykernel_28648\3444394695.py:27: FutureWarning: Passing literal html to 'read_html' is deprecated and will be removed in a future version. To read from a literal string, wrap it in a 'StringIO' object.
      gme_revenue = pd.read_html(str(gme_table))[0]
    


```python
import pandas as pd
import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt

# Function to get Tesla stock data
def get_tesla_stock_data():
    try:
        url = 'https://query1.finance.yahoo.com/v7/finance/download/TSLA?period1=0&period2=9999999999&interval=1d&events=history'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an error for non-200 status codes
        stock_data = pd.read_csv(url)
        stock_data['Date'] = pd.to_datetime(stock_data['Date'])
        stock_data.set_index('Date', inplace=True)
        return stock_data
    except Exception as e:
        print("Failed to retrieve Tesla stock data:", e)

# Function to get Tesla revenue data
def get_tesla_revenue_data():
    try:
        url = 'https://www.macrotrends.net/stocks/charts/TSLA/tesla/revenue'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an error for non-200 status codes
        soup = BeautifulSoup(response.content, 'html.parser')
        table = soup.find('table', class_='historical_data_table')
        revenue_data = pd.read_html(str(table))[0]
        revenue_data['Date'] = pd.to_datetime(revenue_data['Date'])
        revenue_data.set_index('Date', inplace=True)
        return revenue_data
    except Exception as e:
        print("Failed to retrieve Tesla revenue data:", e)

# Get Tesla stock data
tesla_stock_data = get_tesla_stock_data()

# Get Tesla revenue data
tesla_revenue_data = get_tesla_revenue_data()

# Check if data was retrieved successfully
if tesla_stock_data is not None and tesla_revenue_data is not None:
    # Plotting the data
    plt.figure(figsize=(12, 6))

    # Plotting Tesla stock data
    plt.plot(tesla_stock_data.index, tesla_stock_data['Close'], label='Tesla Stock Price', color='blue')

    # Plotting Tesla revenue data
    plt.plot(tesla_revenue_data.index, tesla_revenue_data['Revenue'], label='Tesla Revenue', color='red')

    # Adding labels and title
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.title('Tesla Stock Price vs Revenue')
    plt.legend()

    # Rotating x-axis labels for better readability
    plt.xticks(rotation=45)

    # Show plot
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve one or both sets of data. Please check the error messages above.")

```

    Failed to retrieve Tesla revenue data: 'Date'
    Failed to retrieve one or both sets of data. Please check the error messages above.
    

    C:\Users\saran\AppData\Local\Temp\ipykernel_28648\1910410951.py:29: FutureWarning: Passing literal html to 'read_html' is deprecated and will be removed in a future version. To read from a literal string, wrap it in a 'StringIO' object.
      revenue_data = pd.read_html(str(table))[0]
    


```python
import pandas as pd
import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt

# Function to get Tesla stock data
def get_tesla_stock_data():
    try:
        url = 'https://query1.finance.yahoo.com/v7/finance/download/TSLA?period1=0&period2=9999999999&interval=1d&events=history'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an error for non-200 status codes
        stock_data = pd.read_csv(url)
        stock_data['Date'] = pd.to_datetime(stock_data['Date'])
        stock_data.set_index('Date', inplace=True)
        return stock_data
    except Exception as e:
        print("Failed to retrieve Tesla stock data:", e)

# Function to get Tesla revenue data
def get_tesla_revenue_data():
    try:
        url = 'https://www.macrotrends.net/stocks/charts/TSLA/tesla/revenue'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an error for non-200 status codes
        soup = BeautifulSoup(response.content, 'html.parser')
        table = soup.find('table', class_='historical_data_table')
        revenue_data = pd.read_html(str(table))[0]
        revenue_data['Date'] = pd.to_datetime(revenue_data['Date'])
        revenue_data.set_index('Date', inplace=True)
        return revenue_data
    except Exception as e:
        print("Failed to retrieve Tesla revenue data:", e)

# Get Tesla stock data
tesla_stock_data = get_tesla_stock_data()

# Get Tesla revenue data
tesla_revenue_data = get_tesla_revenue_data()

# Check if data was retrieved successfully
if tesla_stock_data is not None and tesla_revenue_data is not None:
    # Plotting the data
    plt.figure(figsize=(12, 6))

    # Plotting Tesla stock data
    plt.plot(tesla_stock_data.index, tesla_stock_data['Close'], label='Tesla Stock Price', color='blue')

    # Plotting Tesla revenue data
    plt.plot(tesla_revenue_data.index, tesla_revenue_data['Revenue'], label='Tesla Revenue', color='red')

    # Adding labels and title
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.title('Tesla Stock Price vs Revenue')
    plt.legend()

    # Rotating x-axis labels for better readability
    plt.xticks(rotation=45)

    # Show plot
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve one or both sets of data. Please check the error messages above.")

```

    Failed to retrieve Tesla revenue data: 'Date'
    Failed to retrieve one or both sets of data. Please check the error messages above.
    

    C:\Users\saran\AppData\Local\Temp\ipykernel_28648\1910410951.py:29: FutureWarning: Passing literal html to 'read_html' is deprecated and will be removed in a future version. To read from a literal string, wrap it in a 'StringIO' object.
      revenue_data = pd.read_html(str(table))[0]
    


```python
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt

# Function to get Tesla stock data
def get_tesla_stock_data():
    try:
        tesla_data = yf.download('TSLA', start='2015-01-01', end='2021-12-31')
        return tesla_data
    except Exception as e:
        print("Failed to retrieve Tesla stock data:", e)

# Function to get Tesla revenue data (fictional data for demonstration)
def get_tesla_revenue_data():
    try:
        # Generating fictional revenue data for demonstration
        dates = pd.date_range(start='2015-01-01', end='2021-12-31', freq='M')
        revenue = [1000000, 1200000, 1300000, 1500000, 2000000, 2500000, 3000000] * len(dates)
        tesla_revenue = pd.DataFrame({'Date': dates, 'Revenue': revenue})
        tesla_revenue.set_index('Date', inplace=True)
        return tesla_revenue
    except Exception as e:
        print("Failed to retrieve Tesla revenue data:", e)

# Get Tesla stock data
tesla_stock_data = get_tesla_stock_data()

# Get Tesla revenue data
tesla_revenue_data = get_tesla_revenue_data()

# Check if data was retrieved successfully
if tesla_stock_data is not None and tesla_revenue_data is not None:
    # Plotting the data
    plt.figure(figsize=(12, 6))

    # Plotting Tesla stock data
    plt.plot(tesla_stock_data.index, tesla_stock_data['Close'], label='Tesla Stock Price', color='blue')

    # Plotting Tesla revenue data
    plt.plot(tesla_revenue_data.index, tesla_revenue_data['Revenue'], label='Tesla Revenue', color='red')

    # Adding labels and title
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.title('Tesla Stock Price vs Revenue')
    plt.legend()

    # Rotating x-axis labels for better readability
    plt.xticks(rotation=45)

    # Show plot
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve one or both sets of data. Please check the error messages above.")

```

    [*********************100%%**********************]  1 of 1 completed

    Failed to retrieve Tesla revenue data: All arrays must be of the same length
    Failed to retrieve one or both sets of data. Please check the error messages above.
    

    
    C:\Users\saran\AppData\Local\Temp\ipykernel_28648\1593517348.py:17: FutureWarning: 'M' is deprecated and will be removed in a future version, please use 'ME' instead.
      dates = pd.date_range(start='2015-01-01', end='2021-12-31', freq='M')
    


```python
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt

# Function to get Tesla stock data
def get_tesla_stock_data():
    try:
        tesla_data = yf.download('TSLA', start='2015-01-01', end='2021-12-31')
        return tesla_data
    except Exception as e:
        print("Failed to retrieve Tesla stock data:", e)

# Function to get Tesla revenue data (fictional data for demonstration)
def get_tesla_revenue_data():
    try:
        # Generating fictional revenue data for demonstration
        dates = pd.date_range(start='2015-01-01', end='2021-12-31', freq='M')
        revenue = [1000000, 1200000, 1300000, 1500000, 2000000, 2500000, 3000000] * (len(dates) // 7)
        tesla_revenue = pd.DataFrame({'Date': dates[:len(revenue)], 'Revenue': revenue})
        tesla_revenue.set_index('Date', inplace=True)
        return tesla_revenue
    except Exception as e:
        print("Failed to retrieve Tesla revenue data:", e)

# Get Tesla stock data
tesla_stock_data = get_tesla_stock_data()

# Get Tesla revenue data
tesla_revenue_data = get_tesla_revenue_data()

# Check if data was retrieved successfully
if tesla_stock_data is not None and tesla_revenue_data is not None:
    # Plotting the data
    plt.figure(figsize=(12, 6))

    # Plotting Tesla stock data
    plt.plot(tesla_stock_data.index, tesla_stock_data['Close'], label='Tesla Stock Price', color='blue')

    # Plotting Tesla revenue data
    plt.plot(tesla_revenue_data.index, tesla_revenue_data['Revenue'], label='Tesla Revenue', color='red')

    # Adding labels and title
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.title('Tesla Stock Price vs Revenue')
    plt.legend()

    # Rotating x-axis labels for better readability
    plt.xticks(rotation=45)

    # Show plot
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve one or both sets of data. Please check the error messages above.")

```

    [*********************100%%**********************]  1 of 1 completed
    C:\Users\saran\AppData\Local\Temp\ipykernel_28648\2949959574.py:17: FutureWarning: 'M' is deprecated and will be removed in a future version, please use 'ME' instead.
      dates = pd.date_range(start='2015-01-01', end='2021-12-31', freq='M')
    


    
![png](output_8_1.png)
    



```python

```
